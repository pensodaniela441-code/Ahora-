package com.ahora.app;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import java.text.*;import java.util.*;

public class MainActivity extends Activity{
 LinearLayout list; SharedPreferences sp; ArrayList<String> tasks=new ArrayList<>();
 public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("ahora",0);load();build();requestNotifications();render();}
 void requestNotifications(){if(Build.VERSION.SDK_INT>=33) requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},7);}
 TextView tv(String s,int z){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(Color.rgb(17,24,39));t.setPadding(0,10,0,10);return t;}
 Button btn(String s){Button b=new Button(this);b.setText(s);return b;}
 void build(){
  ScrollView sv=new ScrollView(this); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(28,22,28,90);root.setBackgroundColor(Color.rgb(247,247,248));sv.addView(root);
  TextView title=tv("AHORA",30);title.setTypeface(null,1);root.addView(title);
  TextView date=tv(new SimpleDateFormat("EEEE, d 'de' MMMM",new Locale("es","CO")).format(new Date()),15);root.addView(date);
  TextView hero=tv("¿Qué hago ahora?",15);hero.setTextColor(Color.WHITE);hero.setBackgroundColor(Color.rgb(17,24,39));hero.setPadding(22,22,22,22);root.addView(hero);
  Button add=btn("＋ AGREGAR TAREA");root.addView(add);add.setOnClickListener(v->dialog());
  Button focus=btn("▶ MODO ENFOQUE");root.addView(focus);focus.setOnClickListener(v->focusDialog());
  Button week=btn("📊 RESUMEN SEMANAL");root.addView(week);week.setOnClickListener(v->summary());
  TextView sleep=tv("🌙 Hora de dormir",18);sleep.setTypeface(null,1);root.addView(sleep);
  Button setSleep=btn("Configurar hora de dormir");root.addView(setSleep);setSleep.setOnClickListener(v->sleepDialog());
  list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
  setContentView(sv);
 }
 void dialog(){
  LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(20,5,20,5);
  EditText name=new EditText(this);name.setHint("¿Qué necesitas hacer?");x.addView(name);
  EditText mins=new EditText(this);mins.setHint("Duración en minutos");mins.setInputType(2);x.addView(mins);
  EditText time=new EditText(this);time.setHint("Hora (HH:MM), opcional");x.addView(time);
  new AlertDialog.Builder(this).setTitle("Nueva tarea").setView(x).setPositiveButton("Guardar",(d,w)->{
    String n=name.getText().toString().trim();if(n.isEmpty())return;String m=mins.getText().toString();if(m.isEmpty())m="30";
    String tm=time.getText().toString();tasks.add(n+"|"+m+"|"+(tm.isEmpty()?"":tm)+"|0");save();if(!tm.isEmpty())schedule(n,tm);
  }).setNegativeButton("Cancelar",null).show();
 }
 void render(){
  if(list==null)return;list.removeAllViews();TextView h=tv("📋 Tareas de hoy",20);h.setTypeface(null,1);list.addView(h);
  for(int i=0;i<tasks.size();i++){final int idx=i;String[] a=tasks.get(i).split("\|",-1);String n=a[0],m=a[1],tm=a[2],done=a.length>3?a[3]:"0";
   LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,14,18,14);
   TextView t=tv((done.equals("1")?"✓ ":"")+n,18);if(done.equals("1"))t.setAlpha(.45f);card.addView(t);
   card.addView(tv("⏱ "+m+" min"+(tm.isEmpty()?"":" · "+tm)+(a.length>4?" · aplazada "+a[4]+"x":""),13));
   LinearLayout row=new LinearLayout(this);
   Button start=btn("Empezar");row.addView(start);start.setOnClickListener(v->startTask(n,Integer.parseInt(m)));
   Button snooze=btn("Aplazar");row.addView(snooze);snooze.setOnClickListener(v->snooze(idx));
   Button doneb=btn(done.equals("1")?"Desmarcar":"✓ Hecha");row.addView(doneb);doneb.setOnClickListener(v->{a[3]=done.equals("1")?"0":"1";tasks.set(idx,String.join("|",a));save();});
   card.addView(row);list.addView(card);
  }
  if(tasks.isEmpty())list.addView(tv("Todavía no tienes tareas. Agrega la primera.\n\nAHORA no quiere que hagas todo. Quiere ayudarte a empezar.",15));
 }
 void startTask(String n,int min){new AlertDialog.Builder(this).setTitle("Empieza ahora").setMessage("No tienes que terminar todo.\n\nTrabaja "+min+" minutos en:\n"+n+"\n\nCuando termine el bloque, decide si continúas o descansas.").setPositiveButton("Empezar",null).show();}
 void snooze(int i){String[] a=tasks.get(i).split("\|",-1);int c=a.length>4?Integer.parseInt(a[4]):0;c++;if(c>=3){new AlertDialog.Builder(this).setTitle("🚨 Ya la has aplazado varias veces").setMessage("Llevas "+c+" aplazamientos. No necesitas terminarla ahora: haz solo 10 minutos.").setPositiveButton("Voy a empezar",null).show();}if(a.length>4)a[4]=""+c;else tasks.set(i,String.join("|",a)+"|"+c);save();}
 void focusDialog(){new AlertDialog.Builder(this).setTitle("▶ Modo enfoque").setMessage("Durante 25 minutos: una sola tarea, teléfono lejos y sin buscar perfección.\n\nAl terminar, toma 5 minutos de descanso.").setPositiveButton("Iniciar 25 min", (d,w)->new CountDownTimer(25*60*1000,1000){public void onTick(long x){}public void onFinish(){notifyNow("🎉 Terminaste un bloque de enfoque. Descansa 5 minutos.");}}.start()).setNegativeButton("Cancelar",null).show();}
 void sleepDialog(){TimePicker tp=new TimePicker(this);tp.setIs24HourView(true);new AlertDialog.Builder(this).setTitle("🌙 ¿A qué hora quieres dormir?").setView(tp).setPositiveButton("Guardar",(d,w)->{sp.edit().putInt("sh",tp.getHour()).putInt("sm",tp.getMinute()).apply();notifySleep();}).setNegativeButton("Cancelar",null).show();}
 void summary(){int done=0,snooze=0;for(String q:tasks){String[] a=q.split("\|",-1);if(a.length>3&&a[3].equals("1"))done++;if(a.length>4)snooze+=Integer.parseInt(a[4]);}new AlertDialog.Builder(this).setTitle("📊 Esta semana").setMessage("Tareas registradas: "+tasks.size()+"\nCompletadas: "+done+"\nAplazamientos: "+snooze+"\n\nLa siguiente versión guardará el historial por cada día y calculará metas semanales reales.").setPositiveButton("Entendido",null).show();}
 void save(){StringBuilder b=new StringBuilder();for(String s:tasks)b.append(s).append("\n");sp.edit().putString("tasks",b.toString()).apply();render();}
 void load(){String q=sp.getString("tasks","");if(!q.isEmpty())tasks.addAll(Arrays.asList(q.split("\n")));}
 void schedule(String title,String time){try{String[] p=time.split(":");Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,Integer.parseInt(p[0]));c.set(Calendar.MINUTE,Integer.parseInt(p[1]));c.set(Calendar.SECOND,0);if(c.before(Calendar.getInstance()))c.add(Calendar.DAY_OF_YEAR,1);Intent in=new Intent(this,ReminderReceiver.class);in.putExtra("title","Es hora de empezar: "+title);PendingIntent pi=PendingIntent.getBroadcast(this,(int)(System.currentTimeMillis()/1000),in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);((AlarmManager)getSystemService(ALARM_SERVICE)).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),pi);}catch(Exception e){}}
 void notifySleep(){notifyNow("🌙 Recuerda tu hora de dormir. Mañana también necesitas energía.");}
 void notifyNow(String text){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel("ahora","Recordatorios AHORA",NotificationManager.IMPORTANCE_HIGH));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"ahora"):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("AHORA").setContentText(text).setAutoCancel(true);nm.notify((int)System.currentTimeMillis(),b.build());}
 @Override protected void onResume(){super.onResume();render();}
}
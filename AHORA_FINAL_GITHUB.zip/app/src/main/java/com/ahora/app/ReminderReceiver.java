package com.ahora.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String title = intent.getStringExtra("title");
        if (title == null) title = "Tienes una tarea pendiente";

        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "ahora",
                    "Recordatorios AHORA",
                    NotificationManager.IMPORTANCE_HIGH
            );
            manager.createNotificationChannel(channel);
        }

        Notification.Builder notification =
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                        ? new Notification.Builder(context, "ahora")
                        : new Notification.Builder(context);

        notification
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle("AHORA")
                .setContentText(title)
                .setAutoCancel(true);

        manager.notify((int) System.currentTimeMillis(), notification.build());
    }
}

package com.ahora.app;
import android.app.*;import android.content.*;import androidx.annotation.Nullable;
public class ReminderReceiver extends BroadcastReceiver{
 public void onReceive(Context c,Intent i){
  String title=i.getStringExtra("title"); if(title==null) title="Tienes una tarea pendiente";
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(android.os.Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel("ahora","Recordatorios AHORA",NotificationManager.IMPORTANCE_HIGH));
  Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"ahora"):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("AHORA").setContentText(title).setAutoCancel(true);
  nm.notify((int)System.currentTimeMillis(),b.build());
 }
}
# AHORA — aplicación Android
Aplicación ligera de organización y antiprocrastinación para Android.

Incluye:
- tareas con duración y hora
- recordatorios Android
- aplazamiento con contador
- modo enfoque 25 minutos
- hora de dormir
- resumen
- almacenamiento local
- interfaz ligera para teléfonos como Samsung A12

## Compilar
Requiere Android Studio y JDK 17. Abrir esta carpeta como proyecto Gradle y generar APK desde Build > Build APK(s).
